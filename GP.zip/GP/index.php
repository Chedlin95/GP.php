<!DOCTYPE html>
<html>
<title>Systeme de gestion</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
body {font-family: "Times New Roman", Georgia, Serif;}
h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
</style>
<head></head>
<body>

<header>
    <?php  
    require("menu.php");
    
    ?>
      <p style='color:black; text_align:center; font-size:33px; '><marquee behavior="" direction="left">Bienvenue à</marquee> </p>
                  
  <img class="w3-image  w3-animate-fading" src="unnamed.png" alt="Norway" width="1600" height="800">
  </header>

<div class="w3-content" style="max-width:1100px">

  <div class="w3-row w3-padding-64" id="about">
    <div class="w3-col m6 w3-padding-large w3-hide-small">
    
    </div>

    <div class="w3-col m6 w3-padding-large">
      
  </div> 
  </div> 

</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer> 
<br>
<br> 29, 2eme RUELLE NAZON, PORT-AU-PRINCE <br>
                 TEL:+ (509) 2226-4789 / 3778-6922 <br>
                           WWW.ESIH.EDU
                           </footer> 

</body>
</html>