<?php
    class Personne
    {
       private $code;
       private $nom;
       private $prenom;
       private $sexe;
       private $nationalite;
       private $date_nais;
       private $tel;
       private $email;
       private $type;

       public function __construct($code_p,$nom_p,$prenom_p,$sexe_p,$nationalite_p,$date_nais_p,$tel_p,$email_p,$type_p)
       {
            $this->code = $code_p;  
            $this->nom = $nom_p;
            $this->prenom = $prenom_p; 
            $this->sexe = $sexe_p;
            $this->nationalite = $nationalite_p;  
            $this->date_nais = $date_nais_p;
            $this->tel = $tel_p; 
            $this->email = $email_p;
            $this->type = $type_p;
       } 
       
       public function getcode()
       {
           return $this->code;
       }

       public function setcode()
       {
           return $this->code;
       }




       public function getnom()
       {
           return $this->nom;
       }
       
       public function setnom()
       {
           return $this->nom;
       }


       public function getprenom()
       {
           return $this->prenom;
       }
       public function setprenom()
       {
           return $this->prenom;
       }


        public function getsexe()
        {
            return $this->sexe;
        }
        public function setsexe()
        {
            return $this->sexe;
        }


        public function getnationalite()
        {
            return $this->nationalite;
        }
        public function setnationalite()
        {
            return $this->nationalite;
        }


        public function getdate_nais()
        {
            return $this->date_nais;
        }
        public function setdate_nais()
        {
            return $this->date_nais;
        }


        public function gettel()
        {
            return $this->tel;
        }
        public function settel()
        {
            return $this->tel;
        }

        public function getemail()
        {
            return $this->email;
        }
        public function setemail()
        {
            return $this->email;
        }


        public function gettype()
        {
            return $this->type;
        }    
        public function settype()
        {
            return $this->type;
        }     


}