
<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="Style.css" type="text/css" />
    <link rel="stylesheet" href="Content/bootstrap.min.css" />
    <title>Document</title>
</head>
<body>
    <div id="page">
                    <header>
                        <?php  
                             include("menu.php");
                        ?>
                        
                            </header>
                <br>
        
                <table width="100%" border="1px" class="w3-table-all w3-striped w3-border">
<tr style =" background-color:gray; color: rgb(16, 55, 58)" >
  <th>Code</th>
  <th>Nom</th>
  <th>Prenom</th>
  <th>Sexe</th>
  <th>Nationalite</th>
  <th>Date Naissance</th>
  <th>Téléphone</th>
  <th>Email</th>
  <th>Type Personne</th>
</tr>
<tr class="w3-hover-red">
<?php 
        foreach($_SESSION['personne'] as $t)

echo("
<tr> 
<td>$t[code]</td>
<td>$t[nom]</td>
<td>$t[prenom]</td>
<td>$t[sexe]</td>
<td>$t[nationalite]</td>
<td>$t[date_nais]</td>
<td>$t[tel]</td>
<td>$t[email]</td>
<td>$t[type]</td>

</tr>

")
     
        ?>
</tr>
</table>

<br>
<a href="frm_personne.php" type="buttom" class="btn btn-primary">Ajouter nouvelle personne</a>
     
</div>
<br><br>
<footer> 
<br><p> 29, 2eme RUELLE NAZON, PORT-AU-PRINCE <br>
                 TEL:+ (509) 2226-4789 / 3778-6922 <br>
                           WWW.ESIH.EDU
</p>
</footer>   
</body>
</html>