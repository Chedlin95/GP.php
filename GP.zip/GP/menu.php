
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css" type="text/css" />
    <link rel="stylesheet" href="Content/bootstrap.min.css" />
    <title>Gestion Ressources humaines</title>
</head>
<body>

                            <nav>
			                     <ul>
                                        <li><a href="index.php"  class=" w3-animate-zoom w3-text-white w3-section ">Accueil</a> </li>
                                        <li><a href="frm_personne.php"  class=" w3-animate-zoom w3-text-white w3-section ">Enregistre Personnes</a></li>
                                        <li><a href="lister.php"  class=" w3-animate-zoom w3-text-white w3-section ">Liste des Personnes</a> </li>
                                     
                                </ul>
                                
                            </nav>

                                                                                              
</body>
</html>